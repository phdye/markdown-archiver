# Markdown Archiver (mdar)

A tool to archive text files within a markdown file.